"use strict";

const http = require("http");

const PORT = Number(process.env.PORT || 8899);
const CONFIG_DELAY_MS = Number(process.env.CONFIG_DELAY_MS || 750);
const FLAG = process.env.FLAG || "WRECKIT7{redacted}";

const server = http.createServer((req, res) => {
  if (req.url !== "/config.json") {
    send(res, 404, "text/plain; charset=utf-8", "not found");
    return;
  }

  setTimeout(() => {
    send(res, 200, "application/json", JSON.stringify({
      enterprise_ui: {
        load_legacy_framework: true,
        framework_path: "/static/angular-1.5.8.min.js",
        policy_ticket: FLAG
      }
    }));
  }, CONFIG_DELAY_MS);
});

function send(res, statusCode, contentType, body) {
  const payload = Buffer.from(body);
  res.writeHead(statusCode, {
    "cache-control": "no-store",
    "content-length": payload.length,
    "content-type": contentType,
    "x-content-type-options": "nosniff"
  });
  res.end(payload);
}

server.listen(PORT, "0.0.0.0");
