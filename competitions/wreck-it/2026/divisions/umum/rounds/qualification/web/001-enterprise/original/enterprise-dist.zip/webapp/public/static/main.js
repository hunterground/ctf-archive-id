"use strict";

(() => {
  const MANAGED_CONFIG_DEADLINE_MS = 150;
  const params = new URLSearchParams(window.location.search);
  const userNote = params.get("note") || "Welcome to the portal.";
  const content = document.getElementById("content");
  const sessionPill = document.querySelector(".session-pill");

  const enterpriseWidgetProfile = {
    ADD_ATTR: ["ng-focus", "ng-blur", "ng-click", "autofocus"]
  };

  content.innerHTML = DOMPurify.sanitize(userNote, enterpriseWidgetProfile);

  async function initEnterprise() {
    try {
      const managedApi = navigator.managed || navigator.device;
      if (!managedApi || typeof managedApi.getManagedConfiguration !== "function") {
        throw new Error("managed configuration unavailable");
      }

      const configPromise = managedApi.getManagedConfiguration(["enterprise_ui"]);
      const config = await withDeadline(configPromise, MANAGED_CONFIG_DEADLINE_MS);
      if (!config || !config.enterprise_ui || !config.enterprise_ui.load_legacy_framework) {
        return;
      }

      const frameworkPath = String(config.enterprise_ui.framework_path || "");
      if (!frameworkPath.startsWith("/static/")) {
        throw new Error("framework path outside static root");
      }

      sessionPill.textContent = "Enterprise session";
      window.enterprisePolicy = Object.freeze({
        policy_ticket: String(config.enterprise_ui.policy_ticket || "")
      });

      const script = document.createElement("script");
      script.src = frameworkPath;
      script.onload = () => {
        [0, 50, 150, 300, 600].forEach((delay) => {
          window.setTimeout(() => {
            if (publishEnterprisePolicy()) {
              focusDeepLink();
            }
          }, delay);
        });
      };
      document.head.appendChild(script);
    } catch {
    }
  }

  function withDeadline(promise, deadlineMs) {
    return Promise.race([
      promise,
      new Promise((resolve, reject) => {
        window.setTimeout(() => reject(new Error("managed configuration deadline exceeded")), deadlineMs);
      })
    ]);
  }

  function publishEnterprisePolicy() {
    if (!window.angular || !window.enterprisePolicy) {
      return false;
    }

    const rootElement = window.angular.element(document.documentElement);
    const rootScope = rootElement.scope() || window.angular.element(document.body).scope();
    if (!rootScope) {
      return false;
    }

    rootScope.enterprisePolicy = window.enterprisePolicy;
    if (typeof rootScope.$applyAsync === "function") {
      rootScope.$applyAsync();
    }

    return true;
  }

  function focusDeepLink() {
    if (!window.location.hash) {
      return;
    }

    window.setTimeout(() => {
      const id = decodeURIComponent(window.location.hash.slice(1));
      const target = document.getElementById(id);
      if (target && typeof target.focus === "function") {
        if (document.activeElement === target && typeof target.blur === "function") {
          target.blur();
        }

        target.focus();
      }
    }, 0);
  }

  initEnterprise();
})();
