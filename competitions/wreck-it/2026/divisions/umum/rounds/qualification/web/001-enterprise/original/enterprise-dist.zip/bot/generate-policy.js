"use strict";

const fs = require("fs");

function getOrigin() {
  const raw =
    process.env.CHALLENGE_ORIGIN ||
    process.env.PUBLIC_ORIGIN ||
    "http://webapp";

  return new URL(raw).origin;
}

const origin = getOrigin();

const policy = {
  WebAppInstallForceList: [
    {
      url: `${origin}/`,
      default_launch_container: "tab"
    }
  ],
  ManagedConfigurationPerOrigin: [
    {
      origin,
      managed_configuration_url:
        process.env.MANAGED_CONFIG_URL || "http://config:8899/config.json",
      managed_configuration_hash:
        process.env.MANAGED_CONFIG_HASH || "enterprise-v1"
    }
  ]
};

fs.mkdirSync("/etc/opt/chrome/policies/managed", { recursive: true });
fs.writeFileSync(
  "/etc/opt/chrome/policies/managed/policy.json",
  JSON.stringify(policy, null, 2)
);
