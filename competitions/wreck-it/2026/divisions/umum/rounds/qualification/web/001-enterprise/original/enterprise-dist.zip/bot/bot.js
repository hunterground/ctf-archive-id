"use strict";

const express = require("express");
const puppeteer = require("puppeteer");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = process.env.BOT_BASE_URL || "http://webapp";
const CHALLENGE_ORIGIN = process.env.CHALLENGE_ORIGIN || "http://chall";
const CHROME_BIN = process.env.CHROME_BIN || "/usr/bin/google-chrome-stable";
const MAX_ACTIVE_VISITS = Number(process.env.MAX_ACTIVE_VISITS || 2);
const MAX_REPORT_URL_LENGTH = Number(process.env.MAX_REPORT_URL_LENGTH || 2048);
const blockedHosts = new Set(["admin_bot", "config", "localhost", "127.0.0.1", "0.0.0.0", "::1"]);

let activeVisits = 0;

app.disable("x-powered-by");
app.use(express.urlencoded({ extended: false, limit: "8kb" }));
app.use(express.json({ limit: "8kb" }));

app.get("/healthz", (req, res) => {
  res.json({ ok: true, activeVisits });
});

app.get("/favicon.ico", (req, res) => {
  res.status(204).end();
});

app.post("/report", (req, res) => {
  const submittedUrl = String(req.body.url || "").trim();

  if (activeVisits >= MAX_ACTIVE_VISITS) {
    res.status(429).json({ ok: false, error: "review queue is full" });
    return;
  }

  let target;
  try {
    target = normalizeTarget(submittedUrl);
  } catch (error) {
    res.status(400).json({ ok: false, error: "invalid target" });
    return;
  }

  activeVisits += 1;
  res.status(202).json({ ok: true });

  visit(target)
    .catch(() => {})
    .finally(() => {
      activeVisits -= 1;
    });
});

function normalizeTarget(input) {
  if (!input || input.length > MAX_REPORT_URL_LENGTH) {
    throw new Error("invalid length");
  }

  const parsed = new URL(input);

  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error("unsupported scheme");
  }

  if (parsed.username || parsed.password) {
    throw new Error("userinfo not allowed");
  }

  if (blockedHosts.has(parsed.hostname.toLowerCase())) {
    throw new Error("internal host not allowed");
  }

  return parsed.href;
}

async function visit(url) {
  const browser = await puppeteer.launch({
    executablePath: CHROME_BIN,
    headless: true,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      `--unsafely-treat-insecure-origin-as-secure=${CHALLENGE_ORIGIN},${BASE_URL}`,
      "--host-resolver-rules=MAP chall webapp"
    ]
  });

  try {
    const page = await browser.newPage();

    await page.goto(url, { waitUntil: "networkidle2" });
  } finally {
    await browser.close();
  }
}

if (require.main === module) {
  app.listen(PORT, "0.0.0.0");
}
