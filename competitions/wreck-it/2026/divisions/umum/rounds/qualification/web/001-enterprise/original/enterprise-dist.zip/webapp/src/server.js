"use strict";

const express = require("express");
const path = require("path");

const app = express();
const publicDir = path.join(__dirname, "..", "public");

const PORT = Number(process.env.PORT || 80);
const BOT_URL = process.env.BOT_URL || "http://admin_bot:3000/report";
const MAX_REPORT_URL_LENGTH = Number(process.env.MAX_REPORT_URL_LENGTH || 2048);
const blockedReportHosts = new Set(["admin_bot", "config", "webapp", "localhost", "127.0.0.1", "0.0.0.0", "::1"]);

app.disable("x-powered-by");

app.use((req, res, next) => {
  res.setHeader(
    "Content-Security-Policy",
    [
      "default-src 'self'",
      "script-src 'self'",
      "style-src 'self'",
      "frame-src 'self'",
      "object-src 'none'",
      "base-uri 'none'",
      "form-action 'self'"
    ].join("; ")
  );
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  next();
});

app.use(express.urlencoded({ extended: false, limit: "8kb" }));

app.use("/static", express.static(path.join(publicDir, "static"), {
  fallthrough: false,
  immutable: true,
  maxAge: "1h"
}));

app.get("/", (req, res) => {
  res.sendFile(path.join(publicDir, "index.html"));
});

app.get("/favicon.ico", (req, res) => {
  res.status(204).end();
});

app.post("/report", async (req, res) => {
  const submittedUrl = String(req.body.url || "").trim();

  try {
    const target = normalizePlayerUrl(submittedUrl);
    const response = await fetch(BOT_URL, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ url: target }).toString(),
      signal: AbortSignal.timeout(2500)
    });

    if (!response.ok) {
      throw new Error(`bot returned ${response.status}`);
    }

    res.status(202).type("html").send(renderMessage("Report queued", "The enterprise reviewer will open the submitted portal URL shortly."));
  } catch (error) {
    res.status(400).type("html").send(renderMessage("Report rejected", "Submit an absolute HTTP or HTTPS URL."));
  }
});

function normalizePlayerUrl(input) {
  if (!input || input.length > MAX_REPORT_URL_LENGTH) {
    throw new Error("missing url");
  }

  const parsed = new URL(input);
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error("unsupported scheme");
  }

  if (parsed.username || parsed.password) {
    throw new Error("userinfo not allowed");
  }

  if (blockedReportHosts.has(parsed.hostname.toLowerCase())) {
    throw new Error("internal host not allowed");
  }

  return parsed.href;
}

app.use((req, res) => {
  res.status(404).type("html").send(renderMessage("Not found", "That resource is not available in this tenant."));
});

function renderMessage(title, body) {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)} - Enterprise</title>
  <link rel="stylesheet" href="/static/style.css">
</head>
<body>
  <main class="message-shell">
    <section class="message-panel">
      <p class="eyebrow">Enterprise Portal</p>
      <h1>${escapeHtml(title)}</h1>
      <p>${escapeHtml(body)}</p>
      <a class="button-link" href="/">Return</a>
    </section>
  </main>
</body>
</html>`;
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

app.listen(PORT, "0.0.0.0");
