import express from 'express';
import type { Request, Response } from 'express';
import { JSDOM } from 'jsdom';
import createDOMPurify from 'dompurify';
import { SanitizeQuery } from '../constants';
import { InternalServerError } from '../utils/errors';

type HeaderOverride = { key?: string; value?: string };
type SanitizeRequestBody = { url?: string; headers?: HeaderOverride[] };

const HEADER_NAME_REGEX = /^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/;

const normalizeHeaderOverrides = (headers: unknown): HeaderOverride[] | null => {
  if (headers === undefined) return [];
  if (!Array.isArray(headers)) return null;

  const normalized: HeaderOverride[] = [];
  for (const entry of headers) {
    if (typeof entry !== 'object' || entry === null) return null;
    const key = typeof entry.key === 'string' ? entry.key.trim() : '';
    if (!key || !HEADER_NAME_REGEX.test(key)) continue;``

    const value = typeof entry.value === 'string' ? entry.value : undefined;
    if (value !== undefined && /[\r\n]/.test(value)) return null;

    normalized.push({ key, value });
  }
  return normalized;
};

const applyHeaderOverrides = (
  source: Headers,
  target: Response,
  overrides: HeaderOverride[]
): void => {
  overrides.forEach(({ key, value }) => {
    if (!key) return;
    const resolved = value ?? source.get(key) ?? source.get(key.toLowerCase());
    if (resolved) {
      target.setHeader(key, resolved);
    }
  });
};

const { window } = new JSDOM('');
const DOMPurify = createDOMPurify(window as unknown as any);

const router = express.Router();

type SanitizeRequest = Request<{}, any, SanitizeRequestBody, SanitizeQuery>;

const extractUrl = (req: SanitizeRequest): string => {
  if (req.method === 'GET') {
    const candidate = Array.isArray(req.query.url) ? req.query.url[0] : req.query.url;
    return typeof candidate === 'string' ? candidate : '';
  }
  return typeof req.body?.url === 'string' ? req.body.url : '';
};

const extractOverrides = (req: SanitizeRequest): HeaderOverride[] | null => {
  if (req.method !== 'POST') {
    return [];
  }
  return normalizeHeaderOverrides(req.body?.headers);
};

const sanitizeHandler = async (req: SanitizeRequest, res: Response) => {
  try {
    const rawValue = extractUrl(req).trim();
    if (!rawValue) {
      return res.status(400).send('Missing url');
    }

    const overrides = extractOverrides(req);
    if (overrides === null) {
      return res.status(400).send('Invalid headers');
    }

    const url = new URL(rawValue);
    const response = await fetch(url.toString());
    const body = await response.text();

    console.log(`Body resp ${body}`);
    const sanitized = DOMPurify.sanitize(body);

    if (overrides.length > 0) {
      applyHeaderOverrides(response.headers, res, overrides);
    }
    console.log(`Sanitized resp ${sanitized}`);
    res.status(200).end(sanitized);
  } catch (error) {
    console.error('Error sanitizing URL:', error);
    InternalServerError("Error curling URL");
  }
};

// router.route('/').get(sanitizeHandler)
router.route('/').post(sanitizeHandler);

export default router;
