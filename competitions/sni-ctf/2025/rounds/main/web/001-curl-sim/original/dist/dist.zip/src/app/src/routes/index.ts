import express from 'express';
import statusRouter from './status';
import sanitizeRouter from './sanitize';
const router = express.Router();

router.use('/status', statusRouter);
router.use('/sanitize', sanitizeRouter);



export default router;
