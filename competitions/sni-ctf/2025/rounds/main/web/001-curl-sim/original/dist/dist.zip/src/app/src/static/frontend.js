document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('sanitize-form');
  const urlInput = document.getElementById('urlInput');
  const headersContainer = document.getElementById('headersContainer');
  const addHeaderButton = document.getElementById('addHeaderButton');
  const statusNode = document.getElementById('status');
  const resultNode = document.getElementById('result');

  const createHeaderRow = (key = '', value = '') => {
    if (!headersContainer) return;
    const row = document.createElement('div');
    row.className = 'header-row';

    const keyInput = document.createElement('input');
    keyInput.type = 'text';
    keyInput.placeholder = 'Header name';
    keyInput.className = 'header-input';
    keyInput.setAttribute('data-header-key', 'true');
    keyInput.value = key;

    const valueInput = document.createElement('input');
    valueInput.type = 'text';
    valueInput.placeholder = 'Custom value (optional)';
    valueInput.className = 'header-input';
    valueInput.setAttribute('data-header-value', 'true');
    valueInput.value = value;

    const removeButton = document.createElement('button');
    removeButton.type = 'button';
    removeButton.className = 'remove-header';
    removeButton.setAttribute('aria-label', 'Remove header');
    removeButton.textContent = '×';
    removeButton.addEventListener('click', () => row.remove());

    row.append(keyInput, valueInput, removeButton);
    headersContainer.appendChild(row);
  };

  addHeaderButton?.addEventListener('click', () => createHeaderRow());
  if (headersContainer && headersContainer.childElementCount === 0) {
    createHeaderRow();
  }

  form?.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!urlInput) return;

    const urlValue = urlInput.value.trim();
    if (!urlValue) {
      statusNode.textContent = 'Please enter a URL.';
      return;
    }

    const headersPayload = headersContainer
      ? Array.from(headersContainer.querySelectorAll('.header-row'))
          .map((row) => {
            const keyField = row.querySelector('input[data-header-key]');
            const valueField = row.querySelector('input[data-header-value]');
            const key = (keyField?.value ?? '').trim();
            const value = (valueField?.value ?? '').trim();
            if (!key) return null;
            return value ? { key, value } : { key };
          })
          .filter(Boolean)
      : [];

    statusNode.textContent = 'Loading sanitized content…';
    resultNode.innerHTML = '';
    try {
      const response = await fetch('/api/sanitize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: urlValue, headers: headersPayload }),
      });
      if (!response.ok) throw new Error('Request failed');
      const sanitized = await response.text();
      resultNode.innerHTML = sanitized;
      statusNode.textContent = 'Sanitized content rendered below.';
    } catch {
      statusNode.textContent = 'Unable to fetch sanitized content. Please verify the URL.';
    }
  });
});