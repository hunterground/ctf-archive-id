import express from 'express';
import cookieParser from 'cookie-parser';
import morgan from 'morgan';
import type { Request, Response } from 'express';
import { PORT } from './constants';
import routes from './routes';
import ErrorMiddleware from './middlewares/ErrorMiddleware';
import logger from './utils/logger';
import { NotFoundError } from './utils/errors';
import path from 'path';


const app = express();

const STATIC_DIR = path.join(__dirname, 'static');
const VIEWS_DIR = path.join(__dirname, 'views');

app.set('views', VIEWS_DIR);
app.set('view engine', 'ejs');


app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use((req, res, next) => {
  res.setHeader('Content-Security-Policy', "default-src 'self';");
  next();
});
app.use(express.static(STATIC_DIR));

app.use('/api', routes);

app.get('/', (_req, res) => {
  res.render('index');
});

app.get('/favicon.ico', (_req, res) => {
  res.status(204).end();
});

app.use(function (_: Request, res: Response, next): void {
  next(NotFoundError());
});

app.use(ErrorMiddleware);

app.listen(PORT, () => logger.info(`Listening on port ${PORT}`));
