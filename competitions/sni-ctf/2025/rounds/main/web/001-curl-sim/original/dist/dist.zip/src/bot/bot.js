const puppeteer = require('puppeteer');
const fs = require('fs');

const CONFIG = {
    APPNAME: process.env['APPNAME'] || "Admin",
    APPURL: process.env['APPURL'] || "http://localhost:3000",
    APPURLREGEX: process.env['APPURLREGEX'] || "^.*$",
    APPFLAG: process.env['APPFLAG'] || "dev{flag}",
    APPLIMITTIME: Number(process.env['APPLIMITTIME'] || "60000"),
    APPLIMIT: Number(process.env['APPLIMIT'] || "5"),
};

console.table(CONFIG);

function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

const launchOptions = (() => {
    const is_x11_exists = fs.existsSync('/tmp/.X11-unix');
    const headless = !(process.env['DISPLAY'] && is_x11_exists);

    /** @type {import('puppeteer').PuppeteerLaunchOptions} */
    const base = {
        headless,
        browser: 'firefox',
        ignoreHTTPSErrors: true,
        args: [
            "-no-remote",
            "--no-sandbox",
            "--disable-setuid-sandbox",
        ],
    };

    return base;
})();

/** @type {import('puppeteer').Browser | null} */
let browserInstance = null;

async function getBrowser() {
    if (!browserInstance) {
        browserInstance = await puppeteer.launch(launchOptions);
        console.log("[BOT] Firefox browser launched");
    }
    return browserInstance;
}

console.log("Bot started (Puppeteer + Firefox)...");

module.exports = {
    name: CONFIG.APPNAME,
    urlRegex: CONFIG.APPURLREGEX,
    rateLimit: {
        windowMs: Number(CONFIG.APPLIMITTIME),
        limit: Number(CONFIG.APPLIMIT)
    },
    /**
     * @param {string} urlToVisit
     */
    bot: async (urlToVisit) => {
        const browser = await getBrowser();

        /** @type {import('puppeteer').Page} */
        const page = await browser.newPage();


        try {
            await browser.setCookie({
                name: 'flag',
                value: CONFIG.APPFLAG,
                domain: new URL(CONFIG.APPURL).hostname,
                url: CONFIG.APPURL,
                httpOnly: false,
            });

            console.log(`[BOT] Visiting: ${urlToVisit}`);

            await page.goto(urlToVisit, {
                waitUntil: 'domcontentloaded',
                timeout: 30 * 1000,
            });

            console.log('[BOT] Page loaded, waiting for payload...');
            await sleep(15000);

            console.log("[BOT] Done waiting, closing page...");
            await page.close();
            return true;
        } catch (e) {
            console.error('[BOT ERROR]', e);
            try {
                await page.close();
            } catch { }
            return false;
        }
    }
};
