#include <stdio.h>
#include <stdlib.h>
int view = 1;

void menu(){
  printf("==== EON-NOTES ====\n"
         "View Allowed? : %s\n"
         "===================\n"
         "1. Add Note\n"
         "2. View Note\n"
         "3. Delete Note\n"
         ">> ",
         view ? "Yea" : "Nah"
        );
}

void error(){
  printf("An error occurred.\n");
}

#define MAX_NOTES 18
char *notes[MAX_NOTES];
int noteCount = 0;

void add_note(){
  if (noteCount < MAX_NOTES) {
    printf("Creating note...\nNote length: ");
    char input[8];
    fgets(input, sizeof(input), stdin);
    int size = atoi(input);
    if (size <= 0xa0 || size > 0x4a0) {
      error();
      return;
    }
    notes[noteCount] = malloc(size);
    printf("Input title: ");
    scanf("%15s", notes[noteCount]);
    getchar();
    printf("Input content: ");
    scanf("%s", notes[noteCount] + 16);
    getchar();
    noteCount++;
  } else {
    error();
  }
}

void view_note(){
  if (!view) { error(); return; }
  view = 0;

  if (noteCount > 0) {
    printf("Index: ");
    char input[8];
    fgets(input, sizeof(input), stdin);
    int index = atoi(input);
    if (index < 0 || index >= noteCount) {
      error();
      return;
    }
    printf("Title: %s\n", notes[index]);
    printf("Content: %s\n", notes[index] + 16);
  } else {
    error();
  }
}

void delete_note(){
  if (noteCount > 0) {
    printf("Index: ");
    char input[8];
    fgets(input, sizeof(input), stdin);
    int index = atoi(input);
    if (index < 0 || index >= noteCount) {
      error();
      return;
    }
    free(notes[index]);
  } else {
    error();
  }
}

int main(){
  setbuf(stdin, NULL);
  setbuf(stdout, NULL);
  setbuf(stderr, NULL);


  char input[4];
  while(1){
    menu();
    fgets(input, sizeof(input), stdin);

    switch(atoi(input)){
      case 1:
        add_note();
        break;
      case 2:
        view_note();
        break;
      case 3:
        delete_note();
        break;
      default:
        printf("Invalid option. Please try again.\n");
    }
    puts("");
  }
}