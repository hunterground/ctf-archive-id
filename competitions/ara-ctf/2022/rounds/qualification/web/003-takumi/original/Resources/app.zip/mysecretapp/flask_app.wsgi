import logging
import sys
import os
logging.basicConfig(stream=sys.stderr)
sys.path.insert(0, "/var/www/html/mysecretapp")
from app_using_flask import app as application
